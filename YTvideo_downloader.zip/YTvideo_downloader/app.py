from flask import Flask, render_template_string, request, send_file
from pytubefix import YouTube  # 👈 instead of pytube
import os

app = Flask(__name__)

html = """
<!DOCTYPE html>
<html>
<head>
    <title>YouTube Downloader</title>
</head>
<body style="text-align:center; margin-top:100px;">
    <h2>YouTube Video Downloader</h2>
    <form method="POST">
        <input type="text" name="url" placeholder="Enter YouTube URL" size="50" required>
        <br><br>
        <button type="submit">Download</button>
    </form>
    {% if message %}
        <p>{{ message }}</p>
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        url = request.form.get("url")

        try:
            yt = YouTube(url)
            stream = yt.streams.get_highest_resolution()
            file_path = stream.download(filename="video.mp4")

            return send_file(file_path, as_attachment=True)

        except Exception as e:
            return render_template_string(html, message=f"⚠️ Error: {str(e)}")

    return render_template_string(html, message=None)

if __name__ == "__main__":
    app.run(debug=True)
